import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BeerModel } from 'src/app/models/beer.model';

@Injectable({
  providedIn: 'root',
})
export class BeersService {
  api = 'https://api.punkapi.com/v2';

  constructor(private http: HttpClient) {}

  getBeers() {
    return this.http.get<BeerModel[]>(`${this.api}/beers`);
  }

  getBeer(id: number) {
    return this.http.get<BeerModel[]>(`${this.api}/beers/${id}`);
  }

  beerPagination(page: number, per_page: number) {
    return this.http.get<BeerModel[]>(
      `${this.api}/beers?page=${page}&per_page=${per_page}`
    );
  }

  findBeersByFoodPairing(food_pairing: string) {
    return this.http.get<BeerModel[]>(`${this.api}/beers?food=${food_pairing}`);
  }
}
