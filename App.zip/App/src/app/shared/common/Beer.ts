import {
  BeerModel,
  IngredientsModel,
  MethodModel,
  VolumeModel,
} from 'src/app/models/beer.model';
import { Ingredients } from './Ingredients';
import { Method } from './Method';
import { Volume } from './Volume';

export class Beer implements BeerModel {
  id: number;
  name: string;
  tagline: string;
  first_brewed: Date | string;
  description: string;
  image_url: string;
  abv: number;
  ibu: number;
  target_fg: number;
  target_og: number;
  ebc: number;
  srm: number;
  ph: number;
  attenuation_level: number;
  volume: VolumeModel;
  boil_volume: VolumeModel;
  method: MethodModel;
  ingredients: IngredientsModel;
  food_pairing: Array<string>;
  brewers_tips: string;
  contributed_by: string;

  constructor() {
    this.id = 0;
    this.name = '';
    this.tagline = '';
    this.first_brewed = '';
    this.description = '';
    this.image_url = '';
    this.abv = 0;
    this.ibu = 0;
    this.target_fg = 0;
    this.target_og = 0;
    this.ebc = 0;
    this.srm = 0;
    this.ph = 0;
    this.attenuation_level = 0;
    this.volume = new Volume();
    this.boil_volume = new Volume();
    this.method = new Method();
    this.ingredients = new Ingredients();
    this.food_pairing = [];
    this.brewers_tips = '';
    this.contributed_by = '';
  }
}
