import { PageEvent } from '@angular/material/paginator';

export class Pager {
  length: number;
  pageSize: number;
  lowValue: number;
  highValue: number;
  pageSizeOptions: Array<number>;
  pageIndex: number;

  constructor() {
    this.length = 3600;
    this.pageSize = 12;
    this.lowValue = 0;
    this.highValue = 12;
    this.pageSizeOptions = [6, 12];
    this.pageIndex = this.getPreset();
  }

  getPreset(): number {
    let pageIndex: any = localStorage.getItem('pageIndex');
    if (pageIndex && !isNaN(pageIndex)) {
      return parseInt(pageIndex);
    } else {
      return 1;
    }
  }

  indexLogic(event: PageEvent): void {
    if (event.pageIndex === this.pageIndex + 1) {
      this.lowValue = this.lowValue + this.pageSize;
      this.highValue = this.highValue + this.pageSize;
    } else if (event.pageIndex === this.pageIndex - 1) {
      this.lowValue = this.lowValue - this.pageSize;
      this.highValue = this.highValue - this.pageSize;
    }
    this.pageIndex = event.pageIndex;
    localStorage.setItem('pageIndex', this.pageIndex.toString());
  }
}
