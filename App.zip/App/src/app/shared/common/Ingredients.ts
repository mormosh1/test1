import {
  AmountModel,
  HopsModel,
  IngredientsModel,
} from 'src/app/models/beer.model';

export class Ingredients implements IngredientsModel {
  malt: Array<AmountModel>;
  hops: Array<HopsModel>;
  yeast: string;
  constructor() {
    this.malt = [];
    this.hops = [];
    this.yeast = '';
  }
}
