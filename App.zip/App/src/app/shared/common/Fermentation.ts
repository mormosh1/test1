import { FermentationModel, VolumeModel } from 'src/app/models/beer.model';
import { Volume } from './Volume';

export class Fermentation implements FermentationModel {
  temp: VolumeModel;
  constructor() {
    this.temp = new Volume();
  }
}
