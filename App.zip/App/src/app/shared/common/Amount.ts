import { AmountModel, VolumeModel } from 'src/app/models/beer.model';
import { Volume } from './Volume';

export class Amount implements AmountModel {
  name: string;
  amount: VolumeModel;

  constructor() {
    this.name = '';
    this.amount = new Volume();
  }
}
