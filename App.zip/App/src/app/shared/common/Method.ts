import {
  FermentationModel,
  MethodModel,
  TempModel,
} from 'src/app/models/beer.model';
import { Fermentation } from './Fermentation';

export class Method implements MethodModel {
  mash_temp: Array<TempModel>;
  fermentation: FermentationModel;
  twist: null | any;
  constructor() {
    this.mash_temp = [];
    this.fermentation = new Fermentation();
    this.twist = null;
  }
}
