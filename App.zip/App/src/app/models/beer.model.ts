import { Unit } from '../enums/Unit.enum';

export interface VolumeModel {
  value: number;
  unit: Unit.Celsius | Unit.Litres | Unit.Grams | Unit.Grams | Unit.None;
}

export interface HopsModel {
  name: string;
  amount: VolumeModel;
  add: string;
  attribute: string;
}

export interface AmountModel {
  name: string;
  amount: VolumeModel;
}

export interface TempModel {
  temp: VolumeModel;
  duration?: number;
}

export interface FermentationModel {
  temp: VolumeModel;
}
export interface MethodModel {
  mash_temp: Array<TempModel>;
  fermentation: FermentationModel;
  twist: null | any;
}

export interface IngredientsModel {
  malt: Array<AmountModel>;
  hops: Array<HopsModel>;
  yeast: string;
}

export interface BeerModel {
  id: number;
  name: string;
  tagline: string;
  first_brewed: Date | string;
  description: string;
  image_url: string;
  abv: number;
  ibu: number;
  target_fg: number;
  target_og: number;
  ebc: number;
  srm: number;
  ph: number;
  attenuation_level: number;
  volume: VolumeModel;
  boil_volume: VolumeModel;
  method: MethodModel;
  ingredients: IngredientsModel;
  food_pairing: Array<string>;
  brewers_tips: string;
  contributed_by: string;
}
