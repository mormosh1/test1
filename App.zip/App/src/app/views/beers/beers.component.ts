import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { BeerModel } from 'src/app/models/beer.model';
import { BeersService } from 'src/app/services/beers/beers.service';
import { Pager } from 'src/app/shared/common/Pager';

@Component({
  selector: 'app-beers',
  templateUrl: './beers.component.html',
  styleUrls: ['./beers.component.scss'],
})
export class BeersComponent implements OnInit {
  search: string = '';
  beersList: Array<BeerModel> = [];
  pager: Pager;

  constructor(private beersService: BeersService) {
    this.pager = new Pager();
  }

  ngOnInit(): void {
    this.subscribeBeersList();
  }

  subscribeBeersList() {
    this.beersService
      .beerPagination(this.pager.pageIndex, this.pager.pageSize)
      .subscribe(
        (data: BeerModel[]) => {
          this.beersList = data;
        },
        (e) => {
          //error handling
          alert(e.message);
        }
      );
  }

  onSubmit(): void {
    if (this.search) {
      this.beersService.findBeersByFoodPairing(this.search).subscribe(
        (data: BeerModel[]) => {
          this.beersList = data;
        },
        (e) => {
          //error handling
          alert(e.message);
        }
      );
    } else {
      this.subscribeBeersList();
    }
  }

  onRemoveSelected(id: number) {
    let index = this.beersList.findIndex((itme: BeerModel) => itme.id === id);
    let ok = confirm(
      `do you want to remove this item? (${this.beersList[index].name})`
    );
    if (ok) {
      this.beersList.splice(index, 1);
      //and send delete request with id
    }
  }
  onReload() {
    this.search = '';
    this.pager.pageIndex = 1;
    this.subscribeBeersList();
  }

  getBeersData(event: PageEvent): void {
    if (event.pageIndex === 0) return;
    if (this.beersList.length > this.pager.pageSize) {
      this.pager.indexLogic(event);
    } else {
      this.beersService
        .beerPagination(this.pager.pageIndex, this.pager.pageSize)
        .subscribe(
          (data: BeerModel[]) => {
            this.pager.indexLogic(event);
            setTimeout(() => (this.beersList = data), 1);
          },
          (e) => {
            //error handling
            alert(e.message);
          }
        );
    }
  }
}
